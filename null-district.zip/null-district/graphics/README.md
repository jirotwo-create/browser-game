# PSX graphics pipeline

`PSXPipeline` renders the world, enemies, weather and world-space tracers through the same low-resolution render target. Player arms and gear are composited afterwards at native window resolution. The world output is enlarged with nearest-neighbor sampling. At a 4:3 aspect ratio the target is 320×240; widescreen preserves 240 vertical pixels and adds horizontal pixels rather than stretching the camera.

## Raster stages

1. Transform low-poly geometry and calculate directional Gouraud lighting at vertices. Flat vertex normals and painted vertex shade values preserve the facets. Textures are display-space 64×64 pixel paintings with a limited shared palette.
2. Quantize projected vertex positions to whole internal raster pixels. Camera movement produces discrete vertex wobble; there is no animated displacement noise.
3. Interpolate UVs affinely in screen space. Encode `(u*w, v*w, w)` as vertex varyings, then divide the interpolated first two components by the third in the fragment shader. This cancels the GPU's normal perspective correction. Each quad is two triangles, so painted features visibly shear across its diagonal at oblique viewing angles.
4. Sample textures with nearest-neighbor filtering, no mipmaps and no anisotropic filtering. Apply the prelit vertex colors and distance fog.
5. Apply the PS1 4×4 signed dither matrix and RGB555 quantization into a second target at the same internal resolution. Nearest-upscale that completed world image to the native window framebuffer.
6. Clear depth and render the player’s arms, gear and attached effects at native window resolution, after world quantization. Gear uses ordinary perspective interpolation and continuous colors, without pixel textures, vertex snapping or affine UVs. Default-framebuffer antialiasing only smooths the native pass; both world targets remain unsampled 240-line rasters. CSS scanlines are an independently switchable display overlay.

Depth testing and near-plane clipping use the GPU. This is a renderer designed around PS1 visual constraints, rather than a cycle-accurate hardware emulator.

## Art

`anatomy.js` creates anatomical oval cross-sections with independently positioned rings, plus explicit facial topology and beveled polygon prisms. `models.js` uses those shapes for the human skull, modeled nose/cheeks/chin, eyes, eyebrows, hair, hands/fingers, tailored torso and jointed limbs. There is no robot helmet or visor. MOURNFANG has a traditional symmetrical polished black-steel blade, an animated sheen, etched runes, a sculpted death-mask crossguard, moving talons, a horn crown, faceted gems and twin articulated charm chains. Buildings retain tapered upper stories, polygonal tanks and ducts, awnings, rooftop antennae and shuttered shops.

`textures.js` paints deterministic 64×64 grime maps: mottled concrete with drips and cracks, oily broken asphalt, rusted steel, stained shutters, worn leather/cloth and dirty skin. Charcoal, grey, olive and rusty brown replace the earlier bright fantasy palette; the blade core uses dark blood red. Nearest-neighbor sampling, affine interpolation, vertex snapping and RGB555 remain unchanged for the world and enemies. Fog uses the new art palette through the existing uniform.

`weapon-rig.js` anchors weapon and gripping fingers to the same transform. Left hands have mirrored anatomical geometry and opposed thumbs. A two-bone solver keeps each 0.37m upper arm/forearm attached to its wrist and constrains the grip to both shoulders' reachable volume. The carbine has trigger contact, fore-end support and a magazine reach during reload. The sword has a two-handed grip and alternating attacks. Moving fangs, glyphs, ruby, core tint and nested chain animate independently at rest; the slash trail uses the blade's measured path and reuses a fixed buffer.

`district.js` batches static painted geometry by material. Animated rigs and explicitly marked collision meshes remain separate. Rendering changes preserve the mission's traversable road and cover positions.

## Compare and verify

- **F6**: affine mapping / perspective-correct mapping.
- **F7**: projected vertex snapping on / off.
- **F8**: ordered dithering on / off. RGB555 quantization remains active.

These options are enabled by default in the game and desktop builds.

With the development preview running:

```sh
node tests/render.cjs
```

The browser test draws a depth-varying triangle through the actual GPU shaders. It reads back raw UV-encoded pixels and compares them with CPU-computed screen-space barycentric interpolation, then repeats with perspective correction and snapped raster vertices. In the test scene, the sampled U coordinate is approximately **0.333 affine** versus **0.157 perspective-correct**. It also verifies that dithering changes framebuffer pixels and that every world color channel belongs to the 32-level RGB555 palette.

`tests/grips.cjs` samples 223 reload/recoil and alternating attack poses. It checks real joint positions and contact gaps, fixed arm lengths, wrapped fingers, the trigger fingertip, mirrored hand anatomy, idle framing and actual changes in the blade’s animated parts.

`tests/weapons.cjs` verifies both starting weapons, the mixed enemy roster, switching, melee range and damage, cooldown, ammunition, reload cancellation and restart. `tests/assets.html` is a model review scene using the same renderer and actual game models.

`tests/mission.cjs` runs the two-chapter campaign playthrough, including all six objectives and both exits. `tests/desktop.cjs` validates local packaged module loading, the affine comparison control, movement, mouse capture, firing, reloading, pause/restart, fullscreen, renderer isolation and offline operation. Set `NULL_DISTRICT_URL` to use another preview port; set `PLAYWRIGHT_MODULE` to use another Playwright installation.


## Chrome & Ash / chapter content

Version 1.4 leaves `psx-renderer.js` unchanged. `neon.js` builds cyan/magenta/violet tube installations, polygonal pavement light pools and dimensional sigils. The pools blend vertex-painted geometry into the same low-resolution target; there is no bloom pass or replacement of the affine shader. `levels.js` defines both chapters' bounds, objectives, supplies, exits and enemy placements, and builds the independent Gothic cathedral map. The district retains its grungy painted surfaces beneath neon shops and conduits.

`enemies.js` authors four modern/cyberpunk humans, three fantasy humans and three monsters. Equipment, clothing and topology distinguish the humans; the quadruped hound, open-ribbed revenant and winged stone demon have separate anatomy. Current archetype geometry ranges from 1,578 to 6,468 triangles. Walking joints, attack wind-ups, the hound tail, netrunner halo and sentinel wings animate in-game.

`systems/combat.js` separates combat decisions from rendering: range/LOS acquisition, locked aim, wind-up, cooldown, melee facing, firearm cones and projectile launch. The game handles moving projectiles with segment/sphere and solid-cover intersections. Level teardown disposes old geometry, owned materials and sign textures before rebuilding, while retaining shared weapon/texture resources. `nullDistrict.navigation()` and `state` provide read-only diagnostics for navigation and playthrough tests.

`tests/combat.mjs`, `tests/roster.cjs` and `tests/campaign.cjs` cover the new attack mechanics, actual models and complete two-chapter progression. `tests/roster.html` renders a hostile archive with the exact game factories and pipeline. Legacy rendering and grip tests remain applicable.


## Version 1.5 / native gear and sculpted characters

The three original world shaders are byte-for-byte unchanged. Only composition/output sizing changes: `target` holds the raw world raster; `processed` holds the world’s RGB555/dither result; `present` nearest-upscales it; the foreground scene then renders on the full-size framebuffer. Diagnostics distinguish `resolution` from `gearResolution` and report `gearPass`. GPU readback tests in `tests/composite.cjs` verify world pixel blocks, native color gradients, toggle isolation and actual sheen animation. `tests/render.cjs` still produces the original affine/perspective UV samples and RGB555 results.

`gear-materials.js` supplies independent perspective-correct equipment shaders. Flat geometric normals produce visible polygonal reflections, a Fresnel rim, narrow specular strips, cool/warm reflection bands and a time-driven sheen. These materials never register with world retro controls. The polished black-steel blade has four main diamond-section bevels, a ricasso, distal taper and a traditional symmetrical point. Additional ornament meshes preserve independent talon, rune, gem and chain animation. No low-resolution world texture maps are used on the player’s gear.

`sculpt.js` adds raised triangular planes to enemies and carbine surfaces without moving the original mesh boundaries or UV seams. Human limbs/torso also gain additional authored anatomical sections. Character meshes are then merged only among siblings with the same material: joint groups and animated props survive. The new world-rendered enemy budgets are 1,578–6,468 triangles. Environment mesh factories and textures are untouched.


## Version 1.6 / Japanese neon districts

`urban-levels.js` adds three independent maps: the covered market's central/outer shopping lanes, the terminal's divided platforms and wrecked trains, and the open broadcast plaza's service blocks and advertisement skyline. `levels.js` supplies per-chapter interaction verbs, completion copy, transitions and exits. The menu and progression use the chapter array rather than a hard-coded two-level limit. Player gear, original world shaders, enemy models and combat tuning are unchanged.

`signage.js` loads a local OpenType/WOFF font through `FontFace` before painting any signs. `graphics/fonts/DistrictJP.woff` is a renamed, subsetted Noto Sans CJK JP Bold with its OFL notice alongside it. Rebuild with `python tools/subset-sign-font.py /path/to/NotoSansCJK-Bold.ttc` after adding new Japanese characters; fontTools is only a development dependency. The desktop local protocol permits the bundled font; no external font request is needed.

Seventeen authored bilingual ad designs use short Japanese headlines, large English copy, offers and geometric pictograms. Two frames change illuminated accents while preserving the headline. Text is drawn at uniform font scale, never horizontally squeezed. Textures match panel aspect ratios; portrait panels use stacked/grid Japanese layouts, not stretched landscape art. All ads use the world material and share its affine mapping, pixelation and fog. Eighty billboard instances can reuse materials by design and panel aspect. Animation switches cached texture uniforms instead of repainting or allocating GPU textures every frame. Teardown disposes all frame textures, including inactive ones.

`tests/signage.cjs` checks font availability, headline/English/offer bounds, aspect matching and persistent copy during animation. `tests/chapters.cjs` checks new chapter spawns, flood-fills actual collider rectangles to every node/exit, checks animated world signs and exercises restart. `tests/campaign.cjs` navigates and fights through all five chapters with real inputs and validates all fifteen objectives and sequential transitions. `tests/desktop.cjs` loads the bundled font and new chapters through the packaged offline protocol.
