const{chromium}=require(process.env.PLAYWRIGHT_MODULE||'/workspace/dreadwake-tools/node_modules/playwright');const assert=require('node:assert/strict');
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});try{const p=await b.newPage({viewport:{width:960,height:640}});const errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(process.env.NULL_DISTRICT_URL||'http://127.0.0.1:4180');await p.waitForFunction(()=>window.nullDistrict);await p.evaluate(()=>document.getElementById('game').requestPointerLock=()=>Promise.resolve());assert.equal(await p.locator('[data-level]').count(),5);const start=await p.locator('#start').boundingBox();assert.ok(start.y+start.height<640,'Chapter selection/start must fit the minimum desktop size');
for(const index of [2,3,4]){
 await p.click(`[data-level="${index}"]`);await p.click('#start');let s=await p.evaluate(()=>nullDistrict.state),g=await p.evaluate(()=>nullDistrict.graphics());assert.equal(s.level,index+1);assert.equal(s.relays,0);assert.equal(g.signFontReady,true);assert.ok(g.animatedAdvertisements>=20);assert.ok(g.advertCopy.length>=7);
 const nav=await p.evaluate(()=>nullDistrict.navigation());const valid=(x,z,r=.32)=>Math.abs(x)<=nav.bounds.x&&z>=nav.bounds.minZ&&z<=nav.bounds.maxZ&&!nav.solids.some(b=>Math.abs(x-b.x)<b.w/2+r&&Math.abs(z-b.z)<b.d/2+r);
 assert.ok(valid(s.position.x,s.position.z),'Player spawn must be clear');for(const t of s.targets)assert.ok(valid(t.x,t.z,t.type==='gargoyle'?.55:.32),'Clear enemy spawn '+JSON.stringify(t));
 // Flood actual collision rectangles to ensure every objective and exit are accessible.
 const step=.5,queue=[[Math.round(s.position.x/step),Math.round(s.position.z/step)]],seen=new Set(queue.map(p=>p.join(',')));
 for(let i=0;i<queue.length;i++){const[x,z]=queue[i];for(const[dx,dz]of[[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,nz=z+dz,key=nx+','+nz;if(!seen.has(key)&&valid(nx*step,nz*step,.35)){seen.add(key);queue.push([nx,nz]);}}}
 for(const point of [...s.nodes,s.exit])assert.ok(queue.some(([x,z])=>Math.hypot(x*step-point.x,z*step-point.z)<2.4),'Objective/exit reachable '+JSON.stringify(point));
 const firstFrames=g.advertCopy.map(a=>a.frame);await p.waitForTimeout(1900);const nextFrames=await p.evaluate(()=>nullDistrict.graphics().advertCopy.map(a=>a.frame));assert.notDeepEqual(firstFrames,nextFrames,'In-world ads actually change frames');
 await p.keyboard.press('Escape');await p.click('#restart');s=await p.evaluate(()=>nullDistrict.state);assert.equal(s.level,index+1);assert.equal(s.relays,0);assert.equal(s.ammo,24);assert.equal(s.health,100);await p.keyboard.press('Escape');await p.click('#to-menu');
 console.log('PASS chapter '+(index+1)+': spawns, all objective/exit routes, Japanese font, '+g.animatedAdvertisements+' animated boards and restart.');
}
assert.deepEqual(errors,[]);}finally{await b.close()}})().catch(e=>{console.error(e);process.exitCode=1});
